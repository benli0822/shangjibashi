//
//  MYUtil.h
//  Diancai
//
//  Created by james on 20/01/15.
//  Copyright (c) 2015 Xiaojun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface MYUtil : NSObject

+ (UIImage *)imageWithImage:(UIImage *)sourceImage targetSize:(CGSize)size;
@end
