//
//  JasonHelper.h
//  Diancai
//
//  Created by james on 28/01/15.
//  Copyright (c) 2015 Xiaojun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JsonHelper : NSObject


+(void)sendJsonDataWithDictionary : (NSDictionary*) data;
@end
