//
//  MDActivicy.m
//  Diancai
//
//  Created by james on 06/11/14.
//  Copyright (c) 2014 Xiaojun. All rights reserved.
//

#import "MDActivicy.h"

@implementation MDActivicy

@end
