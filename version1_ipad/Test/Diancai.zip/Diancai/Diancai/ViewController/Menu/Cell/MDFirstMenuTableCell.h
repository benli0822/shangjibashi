//
//  MDFirstMenuTableCellTableViewCell.h
//  Diancai
//
//  Created by james on 11/11/14.
//  Copyright (c) 2014 Xiaojun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MDFirstMenuTableCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *firstMenuLabel;

@end
