//
//  ViewController.h
//  Diancai
//
//  Created by james on 22/09/14.
//  Copyright (c) 2014 Xiaojun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MDMainViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *orderButton;

@end

